// Your GitHub Username
var username='username';

// Refresh data feed timer
var reloadGitHubFeedTimeout = 3600;
